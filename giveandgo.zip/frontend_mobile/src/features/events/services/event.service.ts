import { apiClient } from '../../../services/api/apiClient';
import { Evento, Postulacion } from '../models/event.models';

const normalizeEvent = (evt: any): Evento => {
  if (!evt) return evt;
  const idNum = evt.id_evento !== undefined ? evt.id_evento : (evt.id ? parseInt(String(evt.id).replace('evt_', ''), 10) : 0);
  return {
    id_evento: idNum,
    id: evt.id || `evt_${idNum}`,
    titulo: evt.titulo || evt.nombre || 'Sin título',
    nombre: evt.nombre || evt.titulo || 'Sin título',
    descripcion: evt.descripcion || '',
    id_categoria: evt.id_categoria || (evt.categoriaId ? parseInt(String(evt.categoriaId).replace('cat_', ''), 10) : 1),
    nombre_categoria: evt.nombre_categoria || evt.categoria || 'General',
    categoria: evt.categoria || evt.nombre_categoria || 'General',
    id_organizacion: evt.id_organizacion || (evt.organizacionId ? parseInt(String(evt.organizacionId).replace('org_', ''), 10) : 1),
    nombre_organizacion: evt.nombre_organizacion || evt.organizacionNombre || '',
    organizacionNombre: evt.organizacionNombre || evt.nombre_organizacion || '',
    organizacion_verificada: evt.organizacion_verificada ?? true,
    fecha_inicio: evt.fecha_inicio || evt.fecha || new Date().toISOString(),
    fecha: evt.fecha || evt.fecha_inicio || new Date().toISOString(),
    hora_inicio: evt.hora_inicio || '08:00',
    hora_fin: evt.hora_fin || '12:00',
    cupo_maximo: evt.cupo_maximo || evt.cupo || 20,
    cupos_disponibles: evt.cupos_disponibles ?? evt.vacantesVoluntarios ?? evt.cupo ?? 20,
    cupos_ocupados: evt.cupos_ocupados || 0,
    vacantesVoluntarios: evt.vacantesVoluntarios ?? evt.vacantes_voluntarios ?? evt.cupos_disponibles ?? 20,
    vacantes_voluntarios: evt.vacantes_voluntarios ?? evt.vacantesVoluntarios ?? evt.cupos_disponibles ?? 20,
    vacantesBeneficiarios: evt.vacantesBeneficiarios ?? evt.vacantes_beneficiarios ?? 20,
    vacantes_beneficiarios: evt.vacantes_beneficiarios ?? evt.vacantesBeneficiarios ?? 20,
    ayuda_ofrecida: evt.ayuda_ofrecida || evt.ayudaOfrecida || '',
    ayudaOfrecida: evt.ayudaOfrecida || evt.ayuda_ofrecida || '',
    publicoObjetivo: evt.publicoObjetivo || evt.publico_objetivo || 'ambos',
    publico_objetivo: evt.publico_objetivo || evt.publicoObjetivo || 'ambos',
    nombre_lugar: evt.nombre_lugar || '',
    punto_referencia: evt.punto_referencia || '',
    direccion: evt.direccion || '',
    barrio: evt.barrio || '',
    localidad: evt.localidad || 'Kennedy',
    ciudad: evt.ciudad || 'Bogotá',
    departamento: evt.departamento || 'Bogotá D.C.',
    pais: evt.pais || 'Colombia',
    latitud: evt.latitud || null,
    longitud: evt.longitud || null,
    estado: evt.estado || 'activo',
    imagen_url: evt.imagen_url || evt.imagen || '',
    imagen: evt.imagen || evt.imagen_url || '',
  } as any;
};

export const eventFeatureService = {
  async getAll(categoriaId?: number): Promise<Evento[]> {
    const params: any = {};
    if (categoriaId) params.categoria = categoriaId;
    const res = await apiClient.get('/events', { params });
    const rawList = res.data.data || [];
    return rawList.map(normalizeEvent);
  },

  async getById(id: number | string): Promise<Evento> {
    const res = await apiClient.get(`/events/${id}`);
    return normalizeEvent(res.data.data);
  },

  async create(data: Partial<Evento> & { organizacionId?: string | number }): Promise<Evento> {
    const payload: any = {
      nombre: data.titulo || (data as any).nombre,
      titulo: data.titulo || (data as any).nombre,
      descripcion: data.descripcion,
      fecha: data.fecha_inicio || (data as any).fecha,
      fecha_inicio: data.fecha_inicio || (data as any).fecha,
      hora_inicio: data.hora_inicio || '08:00',
      hora_fin: data.hora_fin || '12:00',
      cupo: data.cupo_maximo || (data as any).cupo,
      cupo_maximo: data.cupo_maximo || (data as any).cupo,
      vacantesVoluntarios: data.vacantesVoluntarios ?? data.vacantes_voluntarios ?? data.cupo_maximo ?? 10,
      vacantesBeneficiarios: data.vacantesBeneficiarios ?? data.vacantes_beneficiarios ?? 20,
      ayudaOfrecida: data.ayuda_ofrecida || data.ayudaOfrecida || '',
      ayuda_ofrecida: data.ayuda_ofrecida || data.ayudaOfrecida || '',
      publicoObjetivo: data.publicoObjetivo || data.publico_objetivo || 'ambos',
      publico_objetivo: data.publico_objetivo || data.publicoObjetivo || 'ambos',
      nombre_lugar: data.nombre_lugar || '',
      punto_referencia: data.punto_referencia || '',
      categoria: data.id_categoria || (data as any).categoria || 1,
      id_categoria: data.id_categoria || 1,
      direccion: data.direccion,
      barrio: data.barrio,
      localidad: data.localidad || 'Kennedy',
      ciudad: data.ciudad || 'Bogotá',
      departamento: data.departamento || 'Bogotá D.C.',
      pais: data.pais || 'Colombia',
      latitud: data.latitud !== undefined ? data.latitud : null,
      longitud: data.longitud !== undefined ? data.longitud : null,
      imagen: data.imagen || data.imagen_url || '',
      estado: data.estado || 'activo',
    };
    if ((data as any).organizacionId || data.id_organizacion) {
      payload.organizacionId = (data as any).organizacionId || `org_${data.id_organizacion}`;
      payload.id_organizacion = data.id_organizacion;
    }
    const res = await apiClient.post('/events', payload);
    return normalizeEvent(res.data.data);
  },

  async update(id: number | string, data: Partial<Evento>): Promise<Evento> {
    const payload = {
      ...data,
      nombre: data.titulo || (data as any).nombre,
      vacantesVoluntarios: data.vacantesVoluntarios ?? data.vacantes_voluntarios,
      vacantesBeneficiarios: data.vacantesBeneficiarios ?? data.vacantes_beneficiarios,
      ayudaOfrecida: data.ayuda_ofrecida || data.ayudaOfrecida,
      publicoObjetivo: data.publicoObjetivo || data.publico_objetivo,
    };
    const res = await apiClient.put(`/events/${id}`, payload);
    return normalizeEvent(res.data.data);
  },

  async delete(id: number | string): Promise<boolean> {
    const res = await apiClient.delete(`/events/${id}`);
    return res.data.success;
  },

  async registerParticipant(eventoId: number | string, tipo?: 'voluntario' | 'beneficiario', usuarioId?: number | string): Promise<{ success: boolean; message?: string }> {
    const res = await apiClient.post(`/events/${eventoId}/register`, {
      tipo: tipo || 'voluntario',
      ...(usuarioId ? { usuarioId } : {}),
    });
    return res.data;
  },

  async applyBeneficiaryPostulacion(eventoId: number | string, usuarioId: number | string, observaciones?: string): Promise<{ success: boolean; message?: string }> {
    const res = await apiClient.post('/postulaciones', {
      id_evento: eventoId,
      id_usuario: usuarioId,
      tipo_postulacion: 'beneficiario',
      observaciones: observaciones || 'Postulación registrada desde detalle de jornada.',
    });
    return res.data;
  },

  async getCategories() {
    const res = await apiClient.get('/categories');
    const list = res.data.data || [];
    return list.map((c: any) => ({
      ...c,
      id_categoria: c.id_categoria ?? (c.id ? parseInt(String(c.id).replace('cat_', ''), 10) : 1),
      nombre: c.nombre || c.nombre_categoria || 'Categoría',
    }));
  },

  async getUserPostulaciones(usuarioId: number | string): Promise<Postulacion[]> {
    const res = await apiClient.get(`/postulaciones/usuario/${usuarioId}`);
    return res.data.data || [];
  },
};

export default eventFeatureService;

