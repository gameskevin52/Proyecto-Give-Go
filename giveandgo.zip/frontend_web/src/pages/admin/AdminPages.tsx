import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { 
  UserService, 
  OrganizationService, 
  EventService, 
  DonationService, 
  CategoryService,
  RequestService,
  DonacionCompleta,
  AuditService,
  AuditLog,
  VerificationService
} from '../../services/db';
import { Usuario, Organizacion, Evento, Categoria, UserRole, SolicitudVerificacion } from '../../types';
import { UserLink } from '../../components/UserLink';
import { VerifiedBadge } from '../../components/VerifiedBadge';
import { LocationPicker } from '../../components/LocationPicker';
import { DonationCard } from '../../components/DonationCard';
import { DonationDetailsModal } from '../../components/DonationDetailsModal';
import { AdminTrendCharts } from '../../components/admin/AdminTrendCharts';
import { 
  Button, 
  Input, 
  Select, 
  Card, 
  Modal, 
  Table, 
  Badge, 
  Alert, 
  ConfirmDialog, 
  SearchBar, 
  Pagination, 
  EmptyState,
  Textarea,
  formatCOP,
  formatDate
} from '../../components/UI';
import { usePagination } from '../../hooks';
import { 
  Users, 
  Building2, 
  Calendar, 
  Heart, 
  Tag, 
  Plus, 
  Edit, 
  Trash2, 
  CheckCircle2, 
  TrendingUp, 
  Eye,
  AlertCircle,
  BadgeCheck,
  XCircle,
  FileText,
  Clock,
  Download,
  FileDown
} from 'lucide-react';
import { ExportReportsModal } from '../../components/admin/ExportReportsModal';
import { exportEventsToPDF, exportDonationsToPDF } from '../../utils/pdfExport';

/**
 * ==========================================
 * 1. ADMIN DASHBOARD
 * ==========================================
 */
export const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState({
    usersCount: 0,
    orgsCount: 0,
    eventsCount: 0,
    donationsCount: 0,
    monetaryTotal: 0,
    requestsCount: 0,
  });
  const [allDonations, setAllDonations] = useState<DonacionCompleta[]>([]);
  const [allEvents, setAllEvents] = useState<Evento[]>([]);
  const [allUsers, setAllUsers] = useState<Usuario[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // Filtros Donaciones
  const [donSearch, setDonSearch] = useState('');
  const [donType, setDonType] = useState<'todos' | 'monetaria' | 'objeto'>('todos');

  // Filtros Eventos
  const [eventSearch, setEventSearch] = useState('');
  const [eventStatus, setEventStatus] = useState<'todos' | 'activo' | 'inactivo'>('todos');

  // Filtros Auditorías
  const [auditSearch, setAuditSearch] = useState('');
  const [auditRole, setAuditRole] = useState<'todos' | 'admin' | 'organizacion' | 'voluntario' | 'beneficiario'>('todos');

  // Modal de exportación a PDF
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  useEffect(() => {
    async function loadStats() {
      const users = await UserService.getAll();
      const orgs = await OrganizationService.getAll();
      const events = await EventService.getAll();
      const donations = await DonationService.getAll();
      const requests = await RequestService.getAll();
      const audits = await AuditService.getAll();

      const monetaryVal = donations
        .filter(d => d.tipo === 'monetaria' && d.monetaria)
        .reduce((sum, d) => sum + (d.monetaria?.valor || 0), 0);

      setStats({
        usersCount: users.length,
        orgsCount: orgs.length,
        eventsCount: events.length,
        donationsCount: donations.length,
        monetaryTotal: monetaryVal,
        requestsCount: requests.length,
      });

      setAllDonations(donations.slice().reverse());
      setAllEvents(events.slice().reverse());
      setAllUsers(users);
      setAuditLogs(audits);
    }
    loadStats();
  }, []);

  // Filtrado y paginación Donaciones
  const filteredDonations = allDonations.filter(don => {
    const term = donSearch.toLowerCase();
    const matchesSearch = 
      (don.usuarioNombre || '').toLowerCase().includes(term) ||
      (don.organizacionNombre || '').toLowerCase().includes(term) ||
      (don.categoria || '').toLowerCase().includes(term);
    const matchesType = donType === 'todos' || don.tipo === donType;
    return matchesSearch && matchesType;
  });

  const {
    paginatedData: paginatedDonations,
    currentPage: donPage,
    pageSize: donPageSize,
    totalPages: donTotalPages,
    totalItems: donTotalItems,
    setPage: setDonPage,
    setPageSize: setDonPageSize,
  } = usePagination(filteredDonations, { initialPageSize: 15, pageSizeOptions: [5, 10, 15] });

  // Filtrado y paginación Eventos
  const filteredEvents = allEvents.filter(evt => {
    const term = eventSearch.toLowerCase();
    const matchesSearch = 
      evt.nombre.toLowerCase().includes(term) ||
      (evt.descripcion || '').toLowerCase().includes(term) ||
      (evt.categoria || '').toLowerCase().includes(term);
    const matchesStatus = eventStatus === 'todos' || evt.estado === eventStatus;
    return matchesSearch && matchesStatus;
  });

  const {
    paginatedData: paginatedEvents,
    currentPage: eventPage,
    pageSize: eventPageSize,
    totalPages: eventTotalPages,
    totalItems: eventTotalItems,
    setPage: setEventPage,
    setPageSize: setEventPageSize,
  } = usePagination(filteredEvents, { initialPageSize: 15, pageSizeOptions: [5, 10, 15] });

  // Filtrado y paginación Auditorías
  const filteredAudits = auditLogs.filter(log => {
    const term = auditSearch.toLowerCase();
    const matchesSearch = 
      log.accion.toLowerCase().includes(term) ||
      log.nombre_usuario.toLowerCase().includes(term) ||
      log.rol_usuario.toLowerCase().includes(term);
    const matchesRole = auditRole === 'todos' || log.rol_usuario.toLowerCase() === auditRole.toLowerCase();
    return matchesSearch && matchesRole;
  });

  const {
    paginatedData: paginatedAudits,
    currentPage: auditPage,
    pageSize: auditPageSize,
    totalPages: auditTotalPages,
    totalItems: auditTotalItems,
    setPage: setAuditPage,
    setPageSize: setAuditPageSize,
  } = usePagination(filteredAudits, { initialPageSize: 15, pageSizeOptions: [5, 10, 15] });


  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-neutral-900 uppercase tracking-wider">Dashboard de Administración</h1>
          <p className="text-xs text-neutral-500 mt-1">Monitorea el estado de Give&Go y consulta métricas de participación.</p>
        </div>
        <button
          onClick={() => setIsExportModalOpen(true)}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow transition-all cursor-pointer select-none"
          title="Descargar reportes ejecutivos, de eventos y donaciones en formato PDF"
        >
          <FileDown className="w-4 h-4" />
          <span>Exportar Reportes PDF</span>
        </button>
      </div>

      {/* Componente Recharts de Métricas y Gráficos de Tendencia */}
      <AdminTrendCharts
        events={allEvents}
        users={allUsers}
        donations={allDonations}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Donaciones recientes con filtros y paginación */}
        <Card 
          title="Donaciones Registradas"
          headerAction={
            <button
              onClick={() => exportDonationsToPDF(filteredDonations, { 
                title: 'Reporte de Donaciones - Give&Go',
                filtersApplied: donType !== 'todos' || donSearch ? `Filtro tipo: ${donType}, Búsqueda: "${donSearch || 'ninguna'}"` : 'Todos los registros visibles'
              })}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-bold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg border border-neutral-200 transition-colors cursor-pointer select-none"
              title="Exportar listado actual de donaciones a PDF"
            >
              <Download className="w-3.5 h-3.5 text-neutral-600" />
              <span>Exportar PDF</span>
            </button>
          }
        >
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="flex-1">
                <SearchBar value={donSearch} onChange={setDonSearch} placeholder="Buscar por donante, ONG, causa..." />
              </div>
              <select
                value={donType}
                onChange={(e) => setDonType(e.target.value as any)}
                className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
                aria-label="Filtrar por tipo de donación"
              >
                <option value="todos">Todos los tipos</option>
                <option value="monetaria">Monetarias</option>
                <option value="objeto">En especie</option>
              </select>
            </div>

            <div className="space-y-3">
              {paginatedDonations.length === 0 ? (
                <p className="text-xs text-neutral-400 italic py-4 text-center">No hay donaciones que coincidan con los filtros.</p>
              ) : (
                paginatedDonations.map((don) => (
                  <div key={don.id} className="flex justify-between items-center p-3 bg-neutral-50 rounded-xl border border-neutral-150 text-xs">
                    <div>
                      <p className="font-semibold text-neutral-900">{don.usuarioNombre}</p>
                      <p className="text-[10px] text-neutral-500">Causa: {don.categoria} | Hacia: {don.organizacionNombre}</p>
                    </div>
                    <div className="text-right">
                      {don.tipo === 'monetaria' ? (
                        <span className="font-extrabold text-red-600 text-xs">+{formatCOP(don.monetaria?.valor || 0)}</span>
                      ) : (
                        <span className="font-semibold text-neutral-800">{don.objeto?.cantidad} x {don.objeto?.categoria}</span>
                      )}
                      <p className="text-[9px] text-neutral-400 mt-0.5">{formatDate(don.fecha)}</p>
                    </div>
                  </div>
                ))
              )}
            </div>

            <Pagination
              currentPage={donPage}
              totalPages={donTotalPages}
              onPageChange={setDonPage}
              pageSize={donPageSize}
              onPageSizeChange={setDonPageSize}
              pageSizeOptions={[5, 10, 15]}
              totalItems={donTotalItems}
              itemName="donaciones"
            />
          </div>
        </Card>

        {/* Campañas recientes con filtros y paginación */}
        <Card 
          title="Campañas y Convocatorias"
          headerAction={
            <button
              onClick={() => exportEventsToPDF(filteredEvents, { 
                title: 'Reporte de Campañas y Convocatorias - Give&Go',
                filtersApplied: eventStatus !== 'todos' || eventSearch ? `Filtro estado: ${eventStatus}, Búsqueda: "${eventSearch || 'ninguna'}"` : 'Todos los registros visibles'
              })}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-bold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg border border-neutral-200 transition-colors cursor-pointer select-none"
              title="Exportar listado actual de eventos a PDF"
            >
              <Download className="w-3.5 h-3.5 text-neutral-600" />
              <span>Exportar PDF</span>
            </button>
          }
        >
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="flex-1">
                <SearchBar value={eventSearch} onChange={setEventSearch} placeholder="Buscar evento, causa..." />
              </div>
              <select
                value={eventStatus}
                onChange={(e) => setEventStatus(e.target.value as any)}
                className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
                aria-label="Filtrar por estado del evento"
              >
                <option value="todos">Todos los estados</option>
                <option value="activo">Activos</option>
                <option value="inactivo">Inactivos</option>
              </select>
            </div>

            <div className="space-y-3">
              {paginatedEvents.length === 0 ? (
                <p className="text-xs text-neutral-400 italic py-4 text-center">No hay eventos que coincidan con los filtros.</p>
              ) : (
                paginatedEvents.map((evt) => (
                  <div key={evt.id} className="p-3 bg-neutral-50 rounded-xl border border-neutral-150 text-xs space-y-1">
                    <div className="flex justify-between items-start">
                      <span className="font-bold text-neutral-800">{evt.nombre}</span>
                      <Badge variant={evt.estado === 'activo' ? 'success' : 'neutral'}>
                        {evt.estado}
                      </Badge>
                    </div>
                    <p className="text-[10px] text-neutral-500 line-clamp-1">{evt.descripcion}</p>
                    <div className="flex justify-between text-[9px] text-neutral-400 pt-1">
                      <span>Categoría: {evt.categoria}</span>
                      <span>Fecha: {formatDate(evt.fecha)}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <Pagination
              currentPage={eventPage}
              totalPages={eventTotalPages}
              onPageChange={setEventPage}
              pageSize={eventPageSize}
              onPageSizeChange={setEventPageSize}
              pageSizeOptions={[5, 10, 15]}
              totalItems={eventTotalItems}
              itemName="eventos"
            />
          </div>
        </Card>
      </div>

      {/* Registro de Auditoría con filtros y paginación */}
      <Card title="Registro de Auditoría de Seguridad (System Logs)">
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <p className="text-xs text-neutral-500">Muestra el registro de acciones importantes (Inicios de sesión, actualizaciones de perfiles, eventos y donaciones).</p>
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <div className="w-full sm:w-64">
                <SearchBar value={auditSearch} onChange={setAuditSearch} placeholder="Buscar por acción, usuario..." />
              </div>
              <select
                value={auditRole}
                onChange={(e) => setAuditRole(e.target.value as any)}
                className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
                aria-label="Filtrar por rol de usuario"
              >
                <option value="todos">Todos los roles</option>
                <option value="admin">Admin</option>
                <option value="organizacion">Organización</option>
                <option value="voluntario">Voluntario</option>
                <option value="beneficiario">Beneficiario</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto border border-neutral-150 rounded-xl">
            <table className="min-w-full divide-y divide-neutral-200 text-left text-xs">
              <thead className="bg-neutral-100 text-neutral-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-4 py-3">Fecha y Hora</th>
                  <th className="px-4 py-3">Acción Realizada</th>
                  <th className="px-4 py-3">Usuario</th>
                  <th className="px-4 py-3">Rol</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-150 bg-white">
                {paginatedAudits.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center text-neutral-400 italic">No se encontraron registros de auditoría.</td>
                  </tr>
                ) : (
                  paginatedAudits.map((log, idx) => (
                    <tr key={log.id_audit || idx} className="hover:bg-neutral-50 font-mono text-[11px]">
                      <td className="px-4 py-2.5 text-neutral-500 text-[10px] whitespace-nowrap">
                        {formatDate(log.fecha)} {new Date(log.fecha).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>
                      <td className="px-4 py-2.5 font-sans font-medium text-neutral-900">{log.accion}</td>
                      <td className="px-4 py-2.5 text-neutral-700 whitespace-nowrap">{log.nombre_usuario}</td>
                      <td className="px-4 py-2.5 whitespace-nowrap">
                        <Badge variant={log.rol_usuario.toLowerCase() === 'admin' ? 'danger' : log.rol_usuario.toLowerCase() === 'organizacion' ? 'info' : 'success'}>
                          {log.rol_usuario}
                        </Badge>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <Pagination
            currentPage={auditPage}
            totalPages={auditTotalPages}
            onPageChange={setAuditPage}
            pageSize={auditPageSize}
            onPageSizeChange={setAuditPageSize}
            pageSizeOptions={[5, 10, 15]}
            totalItems={auditTotalItems}
            itemName="registros"
          />
        </div>
      </Card>

      {/* Modal interactivo de exportación de reportes a PDF */}
      <ExportReportsModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        allEvents={allEvents}
        filteredEvents={filteredEvents}
        allDonations={allDonations}
        filteredDonations={filteredDonations}
        usersCount={stats.usersCount}
        orgsCount={stats.orgsCount}
        monetaryTotal={stats.monetaryTotal}
      />
    </div>
  );
};

/**
 * ==========================================
 * 2. ADMIN USERS
 * ==========================================
 */
export const AdminUsers: React.FC = () => {
  const [users, setUsers] = useState<Usuario[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<Usuario | null>(null);
  
  // Selected user for detailed info modal
  const [selectedUser, setSelectedUser] = useState<Usuario | null>(null);
  const [userEvents, setUserEvents] = useState<Evento[]>([]);
  const [userDonations, setUserDonations] = useState<DonacionCompleta[]>([]);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);

  // Confirm Dialog
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<string | null>(null);

  // Form
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<Omit<Usuario, 'id'>>();

  useEffect(() => {
    loadUsers();
  }, []);

  const handleOpenDetails = async (user: Usuario) => {
    setSelectedUser(user);
    setIsDetailsOpen(true);
    setIsLoadingDetails(true);
    try {
      const events = await EventService.getEventsByVolunteer(user.id);
      const donations = await DonationService.getByVolunteer(user.id);
      setUserEvents(events);
      setUserDonations(donations);
    } catch (e) {
      console.error('Error fetching user activity details:', e);
    } finally {
      setIsLoadingDetails(false);
    }
  };

  async function loadUsers() {
    const list = await UserService.getAll();
    setUsers(list);
  }

  const handleOpenCreate = () => {
    setEditingUser(null);
    reset({
      nombre1: '',
      nombre2: '',
      apellido1: '',
      apellido2: '',
      correo: '',
      password: '',
      telefono: '',
      rol: 'voluntario',
      estado: 'activo'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (user: Usuario) => {
    setEditingUser(user);
    setValue('nombre1', user.nombre1);
    setValue('nombre2', user.nombre2 || '');
    setValue('apellido1', user.apellido1);
    setValue('apellido2', user.apellido2 || '');
    setValue('correo', user.correo);
    setValue('telefono', user.telefono);
    setValue('rol', user.rol);
    setValue('estado', user.estado);
    setValue('password', user.password || '');
    setIsModalOpen(true);
  };

  const onSubmit = async (data: Omit<Usuario, 'id'>) => {
    if (editingUser) {
      await UserService.update(editingUser.id, data);
    } else {
      await UserService.create(data);
    }
    loadUsers();
    setIsModalOpen(false);
  };

  const handleOpenDelete = (id: string) => {
    setUserToDelete(id);
    setIsConfirmOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (userToDelete) {
      await UserService.delete(userToDelete);
      loadUsers();
    }
  };

  // Filtros adicionales de rol y estado
  const [roleFilter, setRoleFilter] = useState<'todos' | 'admin' | 'voluntario' | 'beneficiario' | 'organizacion'>('todos');
  const [statusFilter, setStatusFilter] = useState<'todos' | 'activo' | 'inactivo'>('todos');

  // Filtrado
  const filteredUsers = users.filter(u => {
    const term = searchTerm.toLowerCase();
    const matchesSearch =
      u.nombre1.toLowerCase().includes(term) ||
      (u.apellido1 || '').toLowerCase().includes(term) ||
      (u.correo || '').toLowerCase().includes(term) ||
      (u.rol || '').toLowerCase().includes(term);
    const matchesRole = roleFilter === 'todos' || u.rol.toLowerCase() === roleFilter.toLowerCase();
    const matchesStatus = statusFilter === 'todos' || u.estado === statusFilter;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const {
    paginatedData: paginatedUsers,
    currentPage: userPage,
    pageSize: userPageSize,
    totalPages: userTotalPages,
    totalItems: userTotalItems,
    setPage: setUserPage,
    setPageSize: setUserPageSize,
  } = usePagination(filteredUsers, { initialPageSize: 15, pageSizeOptions: [5, 10, 15] });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-black text-neutral-900 uppercase tracking-wider">Gestión de Usuarios</h1>
          <p className="text-xs text-neutral-500 mt-1">Administra accesos, roles y el estado de voluntarios y beneficiarios.</p>
        </div>
        <Button variant="primary" size="sm" onClick={handleOpenCreate}>
          <Plus className="w-4 h-4 mr-1" />
          Registrar Usuario
        </Button>
      </div>

      {/* Barra de Filtros */}
      <div className="bg-white border border-neutral-200 p-4 rounded-xl shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex-1 max-w-md">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Buscar por nombre, correo..." />
        </div>
        <div className="flex items-center flex-wrap gap-2">
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value as any)}
            className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
            aria-label="Filtrar por rol de usuario"
          >
            <option value="todos">Todos los roles</option>
            <option value="voluntario">Voluntarios</option>
            <option value="beneficiario">Beneficiarios</option>
            <option value="organizacion">Organizaciones</option>
            <option value="admin">Administradores</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
            aria-label="Filtrar por estado de usuario"
          >
            <option value="todos">Todos los estados</option>
            <option value="activo">Activos</option>
            <option value="inactivo">Inactivos</option>
          </select>
        </div>
      </div>

      <Table<Usuario>
        headers={['Nombre Completo', 'Correo Electrónico', 'Teléfono', 'Rol', 'Estado', 'Acciones']}
        data={paginatedUsers}
        renderRow={(item) => (
          <tr key={item.id} className="hover:bg-neutral-50">
            <td className="px-5 py-3 font-semibold text-neutral-950">
              <UserLink
                userId={item.id}
                name={`${item.nombre1} ${item.nombre2 || ''} ${item.apellido1} ${item.apellido2 || ''}`.trim()}
                role={item.rol}
                avatar={item.foto}
                size="sm"
              />
            </td>
            <td className="px-5 py-3 text-xs text-neutral-600">{item.correo}</td>
            <td className="px-5 py-3 text-xs text-neutral-600">{item.telefono}</td>
            <td className="px-5 py-3 text-xs">
              <Badge variant={item.rol === 'admin' ? 'danger' : item.rol === 'organizacion' ? 'info' : 'success'}>
                {item.rol}
              </Badge>
            </td>
            <td className="px-5 py-3 text-xs">
              <Badge variant={item.estado === 'activo' ? 'success' : 'neutral'}>
                {item.estado}
              </Badge>
            </td>
            <td className="px-5 py-3 text-xs flex gap-2">
              <button onClick={() => handleOpenDetails(item)} title="Ver perfil e historial" className="p-1 rounded text-neutral-500 hover:text-neutral-950 hover:bg-neutral-100">
                <Eye className="w-4 h-4" />
              </button>
              <button onClick={() => handleOpenEdit(item)} className="p-1 rounded text-neutral-500 hover:text-neutral-950 hover:bg-neutral-100">
                <Edit className="w-4 h-4" />
              </button>
              {item.id !== 'user_admin' && (
                <button onClick={() => handleOpenDelete(item.id)} className="p-1 rounded text-red-500 hover:text-red-700 hover:bg-red-50">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </td>
          </tr>
        )}
      />

      <Pagination
        currentPage={userPage}
        totalPages={userTotalPages}
        onPageChange={setUserPage}
        pageSize={userPageSize}
        onPageSizeChange={setUserPageSize}
        pageSizeOptions={[5, 10, 15]}
        totalItems={userTotalItems}
        itemName="usuarios"
      />

      {/* Modal Formulario */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingUser ? 'Editar Datos de Usuario' : 'Registrar Nuevo Usuario'}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Primer Nombre"
              error={errors.nombre1?.message}
              {...register('nombre1', { required: 'El nombre es obligatorio' })}
            />
            <Input
              label="Segundo Nombre"
              {...register('nombre2')}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Primer Apellido"
              error={errors.apellido1?.message}
              {...register('apellido1', { required: 'El apellido es obligatorio' })}
            />
            <Input
              label="Segundo Apellido"
              {...register('apellido2')}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Correo electrónico"
              type="email"
              error={errors.correo?.message}
              {...register('correo', { required: 'El correo electrónico es obligatorio' })}
            />
            <Input
              label="Contraseña"
              type="password"
              {...register('password', { required: editingUser ? false : 'La contraseña es obligatoria' })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Número de Teléfono"
              error={errors.telefono?.message}
              {...register('telefono', { required: 'El teléfono es obligatorio' })}
            />
            <Select
              label="Rol Asignado"
              options={[
                { value: 'voluntario', label: 'Voluntario' },
                { value: 'beneficiario', label: 'Beneficiario' },
                { value: 'organizacion', label: 'Organización' },
                { value: 'admin', label: 'Administrador' },
              ]}
              {...register('rol')}
            />
          </div>

          <Select
            label="Estado"
            options={[
              { value: 'activo', label: 'Activo' },
              { value: 'inactivo', label: 'Inactivo' },
            ]}
            {...register('estado')}
          />

          <div className="pt-4 flex justify-end gap-2">
            <Button type="button" variant="outline" size="sm" onClick={() => setIsModalOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Guardar Datos
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Eliminar Usuario"
        message="¿Está completamente seguro de eliminar este usuario? Sus credenciales de acceso quedarán inhabilitadas inmediatamente."
      />

      {/* Modal Detalles e Historial de Actividad */}
      <Modal
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        title="Perfil y Registro de Actividad"
      >
        {selectedUser && (
          <div className="space-y-6 text-neutral-800">
            {/* Información del Perfil */}
            <div className="bg-neutral-50 border border-neutral-150 p-4 rounded text-xs space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm font-black text-neutral-900 uppercase">
                  {selectedUser.nombre1} {selectedUser.nombre2} {selectedUser.apellido1} {selectedUser.apellido2}
                </span>
                <Badge variant={selectedUser.rol === 'admin' ? 'danger' : selectedUser.rol === 'organizacion' ? 'info' : 'success'}>
                  {selectedUser.rol}
                </Badge>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-neutral-600 mt-2">
                <p><strong>Correo:</strong> {selectedUser.correo}</p>
                <p><strong>Teléfono:</strong> {selectedUser.telefono}</p>
                <p><strong>Estado de Cuenta:</strong> {selectedUser.estado === 'activo' ? 'Activo' : 'Inactivo'}</p>
              </div>
            </div>

            {/* Listado de Eventos Inscritos */}
            <div className="space-y-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-neutral-900 flex items-center gap-1">
                <Calendar className="w-4 h-4 text-red-600" />
                Participación en Eventos ({userEvents.length})
              </h3>
              {isLoadingDetails ? (
                <p className="text-xs text-neutral-400 italic">Cargando eventos...</p>
              ) : userEvents.length === 0 ? (
                <p className="text-xs text-neutral-400 italic bg-neutral-50 p-3 rounded border border-neutral-150">No está registrado en ningún evento.</p>
              ) : (
                <div className="max-h-40 overflow-y-auto space-y-2 border border-neutral-150 p-1.5 rounded">
                  {userEvents.map(evt => (
                    <div key={evt.id} className="p-2.5 bg-neutral-50 border border-neutral-100 rounded text-xs flex justify-between items-center">
                      <div>
                        <p className="font-semibold text-neutral-900">{evt.nombre}</p>
                        <p className="text-[10px] text-neutral-500">Causa: {evt.categoria} | Dirección: {evt.direccion}</p>
                      </div>
                      <span className="text-[10px] text-neutral-400 whitespace-nowrap ml-4">{formatDate(evt.fecha)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Listado de Donaciones Realizadas */}
            <div className="space-y-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-neutral-900 flex items-center gap-1">
                <Heart className="w-4 h-4 text-red-600" />
                Historial de Donaciones ({userDonations.length})
              </h3>
              {isLoadingDetails ? (
                <p className="text-xs text-neutral-400 italic">Cargando donaciones...</p>
              ) : userDonations.length === 0 ? (
                <p className="text-xs text-neutral-400 italic bg-neutral-50 p-3 rounded border border-neutral-150">No ha realizado ninguna donación.</p>
              ) : (
                <div className="max-h-40 overflow-y-auto space-y-2 border border-neutral-150 p-1.5 rounded">
                  {userDonations.map(don => (
                    <div key={don.id} className="p-2.5 bg-neutral-50 border border-neutral-100 rounded text-xs flex justify-between items-center">
                      <div>
                        <p className="font-semibold text-neutral-900">Destino: {don.organizacionNombre || 'Organización'}</p>
                        <p className="text-[10px] text-neutral-500">Causa: {don.categoria}</p>
                      </div>
                      <div className="text-right ml-4">
                        {don.tipo === 'monetaria' ? (
                          <span className="font-extrabold text-red-600">+{formatCOP(don.monetaria?.valor || 0)}</span>
                        ) : (
                          <span className="font-semibold text-neutral-800">{don.objeto?.cantidad} x {don.objeto?.categoria}</span>
                        )}
                        <p className="text-[9px] text-neutral-400">{formatDate(don.fecha)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

/**
 * ==========================================
 * 3. ADMIN ORGANIZATIONS
 * ==========================================
 */
export const AdminOrganizations: React.FC = () => {
  const [organizations, setOrganizations] = useState<Organizacion[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOrg, setEditingOrg] = useState<Organizacion | null>(null);
  
  // Confirm
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [orgToDelete, setOrgToDelete] = useState<string | null>(null);

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<Omit<Organizacion, 'id'>>();

  useEffect(() => {
    loadOrgs();
  }, []);

  async function loadOrgs() {
    const list = await OrganizationService.getAll();
    setOrganizations(list);
  }

  const handleOpenCreate = () => {
    setEditingOrg(null);
    reset({ nombre: '', direccion: '', correo: '', password: '' });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (org: Organizacion) => {
    setEditingOrg(org);
    setValue('nombre', org.nombre);
    setValue('direccion', org.direccion);
    setValue('correo', org.correo);
    setValue('password', org.password || '');
    setIsModalOpen(true);
  };

  const onSubmit = async (data: Omit<Organizacion, 'id'>) => {
    if (editingOrg) {
      await OrganizationService.update(editingOrg.id, data);
    } else {
      await OrganizationService.create(data);
    }
    loadOrgs();
    setIsModalOpen(false);
  };

  const handleOpenDelete = (id: string) => {
    setOrgToDelete(id);
    setIsConfirmOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (orgToDelete) {
      await OrganizationService.delete(orgToDelete);
      loadOrgs();
    }
  };

  const [verifFilter, setVerifFilter] = useState<'todas' | 'verificada' | 'pendiente' | 'rechazada' | 'no_verificada'>('todas');

  const filteredOrgs = organizations.filter(o => {
    const term = searchTerm.toLowerCase();
    const matchesSearch = 
      o.nombre.toLowerCase().includes(term) ||
      o.direccion.toLowerCase().includes(term) ||
      o.correo.toLowerCase().includes(term);

    const matchesVerif = 
      verifFilter === 'todas' ||
      (verifFilter === 'verificada' && Boolean(o.verificada)) ||
      (verifFilter === 'pendiente' && !o.verificada && o.estadoVerificacion === 'pendiente') ||
      (verifFilter === 'rechazada' && !o.verificada && o.estadoVerificacion === 'rechazada') ||
      (verifFilter === 'no_verificada' && !o.verificada && (!o.estadoVerificacion || o.estadoVerificacion === 'no_solicitado'));

    return matchesSearch && matchesVerif;
  });

  const {
    paginatedData: paginatedOrgs,
    currentPage: orgPage,
    pageSize: orgPageSize,
    totalPages: orgTotalPages,
    totalItems: orgTotalItems,
    setPage: setOrgPage,
    setPageSize: setOrgPageSize,
  } = usePagination(filteredOrgs, { initialPageSize: 15, pageSizeOptions: [5, 10, 15] });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-black text-neutral-900 uppercase tracking-wider">Gestión de Organizaciones</h1>
          <p className="text-xs text-neutral-500 mt-1">Controla los perfiles institucionales de ONGs y fundaciones asociadas.</p>
        </div>
        <Button variant="primary" size="sm" onClick={handleOpenCreate}>
          <Plus className="w-4 h-4 mr-1" />
          Registrar Organización
        </Button>
      </div>

      <div className="bg-white border border-neutral-200 p-4 rounded-xl shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex-1 max-w-md">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Buscar por organización, sede, email..." />
        </div>
        <div className="flex items-center gap-2">
          <select
            value={verifFilter}
            onChange={(e) => setVerifFilter(e.target.value as any)}
            className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
            aria-label="Filtrar por estado de verificación"
          >
            <option value="todas">Todas las organizaciones</option>
            <option value="verificada">Verificadas</option>
            <option value="pendiente">Pendientes de revisión</option>
            <option value="rechazada">Rechazadas</option>
            <option value="no_verificada">No verificadas</option>
          </select>
        </div>
      </div>

      <Table<Organizacion>
        headers={['Id', 'Nombre de la ONG', 'Estado Verificación', 'Dirección Sede', 'Correo de Contacto', 'Acciones']}
        data={paginatedOrgs}
        renderRow={(item) => (
          <tr key={item.id} className="hover:bg-neutral-50">
            <td className="px-5 py-3 text-xs font-semibold text-neutral-500">{item.id}</td>
            <td className="px-5 py-3 font-semibold text-neutral-900">
              <UserLink
                userId={item.id.startsWith('org_') ? item.id : `org_${item.id}`}
                name={item.nombre}
                role="organizacion"
                avatar={item.logo}
                verificada={Boolean(item.verificada)}
                size="sm"
              />
            </td>
            <td className="px-5 py-3 text-xs">
              {item.verificada ? (
                <VerifiedBadge showText size="xs" />
              ) : item.estadoVerificacion === 'pendiente' ? (
                <Badge variant="warning">Pendiente</Badge>
              ) : item.estadoVerificacion === 'rechazada' ? (
                <Badge variant="danger">Rechazada</Badge>
              ) : (
                <Badge variant="neutral">No verificada</Badge>
              )}
            </td>
            <td className="px-5 py-3 text-xs text-neutral-600">{item.direccion}</td>
            <td className="px-5 py-3 text-xs text-neutral-600">{item.correo}</td>
            <td className="px-5 py-3 text-xs flex gap-2">
              <button onClick={() => handleOpenEdit(item)} className="p-1 rounded text-neutral-500 hover:text-neutral-950 hover:bg-neutral-100">
                <Edit className="w-4 h-4" />
              </button>
              <button onClick={() => handleOpenDelete(item.id)} className="p-1 rounded text-red-500 hover:text-red-700 hover:bg-red-50">
                <Trash2 className="w-4 h-4" />
              </button>
            </td>
          </tr>
        )}
      />

      <Pagination
        currentPage={orgPage}
        totalPages={orgTotalPages}
        onPageChange={setOrgPage}
        pageSize={orgPageSize}
        onPageSizeChange={setOrgPageSize}
        pageSizeOptions={[5, 10, 15]}
        totalItems={orgTotalItems}
        itemName="organizaciones"
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingOrg ? 'Editar Organización' : 'Registrar Nueva Sede/ONG'}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Input
            label="Razón Social / Nombre ONG"
            error={errors.nombre?.message}
            {...register('nombre', { required: 'El nombre es obligatorio' })}
          />

          <Input
            label="Dirección de la Sede"
            error={errors.direccion?.message}
            {...register('direccion', { required: 'La dirección es obligatoria' })}
          />

          <Input
            label="Correo de la Organización"
            type="email"
            error={errors.correo?.message}
            {...register('correo', { required: 'El correo es obligatorio' })}
          />

          <Input
            label="Contraseña"
            type="password"
            {...register('password', { required: editingOrg ? false : 'La contraseña es obligatoria' })}
          />

          <div className="pt-4 flex justify-end gap-2">
            <Button type="button" variant="outline" size="sm" onClick={() => setIsModalOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Guardar Datos
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Eliminar Sede Organizativa"
        message="¿Está seguro de eliminar esta organización de la plataforma? Todos los eventos coordinados por esta sede quedarán huérfanos."
      />
    </div>
  );
};

/**
 * ==========================================
 * 3.5 ADMIN VERIFICATIONS (Solicitudes de verificación)
 * ==========================================
 */
export const AdminVerifications: React.FC = () => {
  const [requests, setRequests] = useState<SolicitudVerificacion[]>([]);
  const [filter, setFilter] = useState<'todas' | 'pendiente' | 'aprobada' | 'rechazada'>('todas');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedReq, setSelectedReq] = useState<SolicitudVerificacion | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [actionType, setActionType] = useState<'aprobada' | 'rechazada'>('aprobada');
  const [respuestaAdmin, setRespuestaAdmin] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [alertMsg, setAlertMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    loadRequests();
  }, []);

  async function loadRequests() {
    try {
      const data = await VerificationService.getAllRequests();
      setRequests(data);
    } catch (e) {
      console.error('Error al cargar solicitudes de verificación:', e);
    }
  }

  const handleOpenAction = (req: SolicitudVerificacion, type: 'aprobada' | 'rechazada') => {
    setSelectedReq(req);
    setActionType(type);
    setRespuestaAdmin(type === 'aprobada' ? 'Su organización ha sido verificada con éxito tras revisar la documentación.' : 'La solicitud no pudo ser aprobada en esta ocasión. Por favor revise el NIT y documentos enviados.');
    setIsModalOpen(true);
  };

  const handleConfirmResponse = async () => {
    if (!selectedReq) return;
    setSubmitting(true);
    try {
      await VerificationService.respondRequest(selectedReq.id, actionType, respuestaAdmin);
      setAlertMsg({
        type: 'success',
        text: `Solicitud de ${selectedReq.nombreOrganizacion} fue ${actionType === 'aprobada' ? 'APROBADA' : 'RECHAZADA'} con éxito.`
      });
      setIsModalOpen(false);
      loadRequests();
    } catch (err: any) {
      setAlertMsg({ type: 'error', text: err.message || 'Error al procesar la solicitud' });
    } finally {
      setSubmitting(false);
    }
  };

  const pendingCount = requests.filter(r => r.estado === 'pendiente').length;
  const approvedCount = requests.filter(r => r.estado === 'aprobada').length;
  const rejectedCount = requests.filter(r => r.estado === 'rechazada').length;

  const filteredRequests = requests.filter(r => {
    const matchesFilter = filter === 'todas' || r.estado === filter;
    const term = searchTerm.toLowerCase();
    const matchesSearch = 
      r.nombreOrganizacion.toLowerCase().includes(term) ||
      (r.nit || '').toLowerCase().includes(term) ||
      (r.correoOrganizacion || '').toLowerCase().includes(term);
    return matchesFilter && matchesSearch;
  });

  const {
    paginatedData: paginatedRequests,
    currentPage: reqPage,
    pageSize: reqPageSize,
    totalPages: reqTotalPages,
    totalItems: reqTotalItems,
    setPage: setReqPage,
    setPageSize: setReqPageSize,
  } = usePagination(filteredRequests, { initialPageSize: 15, pageSizeOptions: [5, 10, 15] });


  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-neutral-900 uppercase tracking-wider flex items-center gap-2">
          <BadgeCheck className="w-7 h-7 text-blue-600" />
          Solicitudes de Verificación de Organizaciones
        </h1>
        <p className="text-xs text-neutral-500 mt-1">Revisa las solicitudes de verificación enviadas por las organizaciones y aprueba o rechaza sus credenciales.</p>
      </div>

      {alertMsg && (
        <Alert
          type={alertMsg.type}
          message={alertMsg.text}
          onClose={() => setAlertMsg(null)}
        />
      )}

      {/* Métricas rápidas */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 select-none">
        <Card className="border-l-4 border-l-blue-600">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Total Solicitudes</p>
              <h3 className="text-xl font-black text-neutral-900 mt-0.5">{requests.length}</h3>
            </div>
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
              <BadgeCheck className="w-5 h-5" />
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Pendientes de Revisión</p>
              <h3 className="text-xl font-black text-amber-700 mt-0.5">{pendingCount}</h3>
            </div>
            <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
              <Clock className="w-5 h-5" />
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-l-emerald-600">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Aprobadas</p>
              <h3 className="text-xl font-black text-emerald-800 mt-0.5">{approvedCount}</h3>
            </div>
            <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
        </Card>

        <Card className="border-l-4 border-l-red-600">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Rechazadas</p>
              <h3 className="text-xl font-black text-red-700 mt-0.5">{rejectedCount}</h3>
            </div>
            <div className="p-2.5 bg-red-50 text-red-600 rounded-xl">
              <XCircle className="w-5 h-5" />
            </div>
          </div>
        </Card>
      </div>

      {/* Controles de Filtros y Búsqueda */}
      <div className="bg-white border border-neutral-200 p-4 rounded-xl shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          {(['todas', 'pendiente', 'aprobada', 'rechazada'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer ${
                filter === tab
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              {tab === 'todas' ? 'Todas las Solicitudes' : tab}
              {tab === 'pendiente' && pendingCount > 0 && (
                <span className="ml-1.5 px-1.5 py-0.2 text-[10px] bg-amber-500 text-white rounded-full font-black">
                  {pendingCount}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="w-full md:w-72">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Buscar por ONG, NIT, correo..." />
        </div>
      </div>

      {/* Tabla de Solicitudes */}
      {filteredRequests.length === 0 ? (
        <EmptyState
          title="No se encontraron solicitudes"
          description="Actualmente no existen solicitudes de verificación que coincidan con los filtros seleccionados."
        />
      ) : (
        <>
          <Table<SolicitudVerificacion>
            headers={['Organización', 'NIT', 'Fecha Solicitud', 'Mensaje / Justificación', 'Estado', 'Acciones']}
            data={paginatedRequests}
            renderRow={(item) => (
              <tr key={item.id} className="hover:bg-neutral-50/80 transition-colors">
                <td className="px-5 py-3 font-semibold text-neutral-900">
                  <UserLink
                    userId={item.organizacionId}
                    name={item.nombreOrganizacion}
                    role="organizacion"
                    verificada={item.estado === 'aprobada'}
                    size="sm"
                  />
                  <p className="text-[10px] text-neutral-500 font-normal">{item.correoOrganizacion}</p>
                </td>
                <td className="px-5 py-3 text-xs font-mono font-medium text-neutral-700">{item.nit || 'Sin NIT'}</td>
                <td className="px-5 py-3 text-xs text-neutral-600 whitespace-nowrap">{formatDate(item.fechaSolicitud)}</td>
                <td className="px-5 py-3 text-xs text-neutral-600 max-w-xs">
                  <p className="line-clamp-2 italic">{item.mensaje || 'Sin mensaje adicional.'}</p>
                  {item.documentos && (
                    <p className="text-[10px] text-blue-600 font-medium mt-0.5 truncate">
                      Doc: {item.documentos}
                    </p>
                  )}
                  {item.respuestaAdmin && (
                    <p className="text-[10px] text-neutral-500 font-bold mt-1 bg-neutral-100 p-1 rounded">
                      Respuesta: {item.respuestaAdmin}
                    </p>
                  )}
                </td>
                <td className="px-5 py-3 text-xs whitespace-nowrap">
                  {item.estado === 'aprobada' ? (
                    <Badge variant="success">Aprobada</Badge>
                  ) : item.estado === 'pendiente' ? (
                    <Badge variant="warning">Pendiente</Badge>
                  ) : (
                    <Badge variant="danger">Rechazada</Badge>
                  )}
                </td>
                <td className="px-5 py-3 text-xs whitespace-nowrap">
                  {item.estado === 'pendiente' ? (
                    <div className="flex gap-2">
                      <Button
                        variant="primary"
                        size="sm"
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-2.5 py-1"
                        onClick={() => handleOpenAction(item, 'aprobada')}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                        Aprobar
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-red-300 text-red-600 hover:bg-red-50 font-bold text-xs px-2.5 py-1"
                        onClick={() => handleOpenAction(item, 'rechazada')}
                      >
                        <XCircle className="w-3.5 h-3.5 mr-1" />
                        Rechazar
                      </Button>
                    </div>
                  ) : (
                    <span className="text-[11px] text-neutral-400 italic">
                      Procesada ({item.fechaRespuesta ? formatDate(item.fechaRespuesta) : ''})
                    </span>
                  )}
                </td>
              </tr>
            )}
          />

          <Pagination
            currentPage={reqPage}
            totalPages={reqTotalPages}
            onPageChange={setReqPage}
            pageSize={reqPageSize}
            onPageSizeChange={setReqPageSize}
            pageSizeOptions={[5, 10, 15]}
            totalItems={reqTotalItems}
            itemName="solicitudes"
          />
        </>
      )}

      {/* Modal para Responder Solicitud */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={actionType === 'aprobada' ? 'Aprobar Verificación' : 'Rechazar Verificación'}
      >
        {selectedReq && (
          <div className="space-y-4 text-xs text-neutral-800">
            <div className={`p-3 rounded-xl border ${actionType === 'aprobada' ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-red-50 border-red-200 text-red-900'}`}>
              <p className="font-bold text-sm">{selectedReq.nombreOrganizacion}</p>
              <p className="mt-0.5">NIT: {selectedReq.nit || 'No registrado'} | Email: {selectedReq.correoOrganizacion}</p>
            </div>

            <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-200 space-y-1">
              <p className="font-bold text-neutral-700">Mensaje de la Organización:</p>
              <p className="text-neutral-600 italic">{selectedReq.mensaje || 'No incluyó mensaje de justificación.'}</p>
              {selectedReq.documentos && (
                <p className="text-neutral-600 pt-1"><strong>Documentación adjunta:</strong> {selectedReq.documentos}</p>
              )}
            </div>

            <Textarea
              label="Observaciones o Respuesta del Administrador (Opcional)"
              value={respuestaAdmin}
              onChange={(e) => setRespuestaAdmin(e.target.value)}
              placeholder="Escriba notas para la organización respecto a esta decisión..."
            />

            <div className="pt-2 flex justify-end gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsModalOpen(false)}>
                Cancelar
              </Button>
              <Button
                type="button"
                variant="primary"
                size="sm"
                className={actionType === 'aprobada' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-red-600 hover:bg-red-700'}
                disabled={submitting}
                onClick={handleConfirmResponse}
              >
                {submitting ? 'Guardando...' : actionType === 'aprobada' ? 'Confirmar Aprobación' : 'Confirmar Rechazo'}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

/**
 * ==========================================
 * 4. ADMIN EVENTS
 * ==========================================
 */
export const AdminEvents: React.FC = () => {
  const [events, setEvents] = useState<Evento[]>([]);
  const [categories, setCategories] = useState<Categoria[]>([]);
  const [organizations, setOrganizations] = useState<Organizacion[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Evento | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Confirm
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [eventToDelete, setEventToDelete] = useState<string | null>(null);

  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<Omit<Evento, 'id'>>();

  const watchedLat = watch('latitud');
  const watchedLng = watch('longitud');
  const watchedDireccion = watch('direccion');
  const watchedImagen = watch('imagen');

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setValue('imagen', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  async function loadAll() {
    const list = await EventService.getAll();
    setEvents(list);

    const cats = await CategoryService.getAll();
    setCategories(cats);

    const orgs = await OrganizationService.getAll();
    setOrganizations(orgs);
  }

  const handleOpenCreate = () => {
    setEditingEvent(null);
    setFormError(null);
    reset({
      nombre: '',
      categoria: categories[0]?.nombre || '',
      descripcion: '',
      fecha: '',
      estado: 'activo',
      organizacionId: organizations[0]?.id || '',
      direccion: '',
      barrio: '',
      localidad: 'Kennedy',
      ciudad: 'Bogotá',
      departamento: 'Bogotá D.C.',
      pais: 'Colombia',
      punto_referencia: '',
      nombre_lugar: '',
      latitud: undefined,
      longitud: undefined,
      cupo: 0,
      imagen: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (evt: Evento) => {
    setEditingEvent(evt);
    setFormError(null);
    setValue('nombre', evt.nombre);
    setValue('categoria', evt.categoria);
    setValue('descripcion', evt.descripcion);
    setValue('fecha', evt.fecha);
    setValue('estado', evt.estado);
    setValue('organizacionId', evt.organizacionId);
    setValue('direccion', evt.direccion || '');
    setValue('barrio', evt.barrio || '');
    setValue('localidad', evt.localidad || 'Kennedy');
    setValue('ciudad', evt.ciudad || 'Bogotá');
    setValue('departamento', evt.departamento || 'Bogotá D.C.');
    setValue('pais', evt.pais || 'Colombia');
    setValue('punto_referencia', evt.punto_referencia || '');
    setValue('nombre_lugar', evt.nombre_lugar || '');
    setValue('latitud', evt.latitud || undefined);
    setValue('longitud', evt.longitud || undefined);
    setValue('cupo', evt.cupo || 0);
    setValue('imagen', evt.imagen || '');
    setIsModalOpen(true);
  };

  const handleLocationChange = (coords: {
    lat: number;
    lng: number;
    direccion?: string;
    barrio?: string;
    localidad?: string;
    ciudad?: string;
    departamento?: string;
    pais?: string;
  }) => {
    setValue('latitud', coords.lat);
    setValue('longitud', coords.lng);
    if (coords.direccion) setValue('direccion', coords.direccion);
    if (coords.barrio) setValue('barrio', coords.barrio);
    if (coords.localidad) setValue('localidad', coords.localidad);
    if (coords.ciudad) setValue('ciudad', coords.ciudad);
    if (coords.departamento) setValue('departamento', coords.departamento);
    if (coords.pais) setValue('pais', coords.pais);
  };

  const onSubmit = async (data: Omit<Evento, 'id'>) => {
    setFormError(null);

    // Coordinate validation
    if (data.latitud === undefined || data.latitud === null || isNaN(Number(data.latitud)) ||
        data.longitud === undefined || data.longitud === null || isNaN(Number(data.longitud))) {
      setFormError('Por favor ubica el evento en el mapa interactivo para generar las coordenadas de geolocalización obligatorias.');
      return;
    }

    if (Number(data.latitud) < -90 || Number(data.latitud) > 90 ||
        Number(data.longitud) < -180 || Number(data.longitud) > 180) {
      setFormError('Las coordenadas de latitud/longitud están en un rango inválido.');
      return;
    }

    try {
      const payload = {
        ...data,
        cupo: data.cupo ? parseInt(String(data.cupo), 10) : 0,
        latitud: parseFloat(String(data.latitud)),
        longitud: parseFloat(String(data.longitud))
      };

      if (editingEvent) {
        await EventService.update(editingEvent.id, payload);
      } else {
        await EventService.create(payload);
      }

      loadAll();
      setIsModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Ocurrió un error al guardar el evento.');
    }
  };

  const handleOpenDelete = (id: string) => {
    setEventToDelete(id);
    setIsConfirmOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (eventToDelete) {
      await EventService.delete(eventToDelete);
      loadAll();
    }
  };

  const getOrgName = (orgId: string) => {
    return organizations.find(o => o.id === orgId)?.nombre || 'Organización';
  };

  const [categoryFilter, setCategoryFilter] = useState('todas');
  const [statusFilter, setStatusFilter] = useState<'todos' | 'activo' | 'inactivo'>('todos');

  const filteredEvents = events.filter(e => {
    const term = searchTerm.toLowerCase();
    const matchesSearch = 
      e.nombre.toLowerCase().includes(term) ||
      (e.descripcion || '').toLowerCase().includes(term) ||
      (e.categoria || '').toLowerCase().includes(term);
    const matchesCategory = categoryFilter === 'todas' || e.categoria.toLowerCase() === categoryFilter.toLowerCase();
    const matchesStatus = statusFilter === 'todos' || e.estado === statusFilter;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const {
    paginatedData: paginatedEvents,
    currentPage: eventPage,
    pageSize: eventPageSize,
    totalPages: eventTotalPages,
    totalItems: eventTotalItems,
    setPage: setEventPage,
    setPageSize: setEventPageSize,
  } = usePagination(filteredEvents, { initialPageSize: 15, pageSizeOptions: [5, 10, 15] });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-black text-neutral-900 uppercase tracking-wider">Gestión de Eventos</h1>
          <p className="text-xs text-neutral-500 mt-1">Supervisa y autoriza campañas de reforestación, comedores y soporte social.</p>
        </div>
        <Button variant="primary" size="sm" onClick={handleOpenCreate}>
          <Plus className="w-4 h-4 mr-1" />
          Crear Evento
        </Button>
      </div>

      <div className="bg-white border border-neutral-200 p-4 rounded-xl shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex-1 max-w-md">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Buscar por evento, causa..." />
        </div>
        <div className="flex items-center flex-wrap gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
            aria-label="Filtrar por categoría de evento"
          >
            <option value="todas">Todas las categorías</option>
            {categories.map((c) => (
              <option key={c.id} value={c.nombre}>
                {c.nombre}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
            aria-label="Filtrar por estado del evento"
          >
            <option value="todos">Todos los estados</option>
            <option value="activo">Activos</option>
            <option value="inactivo">Inactivos</option>
          </select>
        </div>
      </div>

      <Table<Evento>
        headers={['Campaña', 'Categoría', 'ONG Responsable', 'Fecha', 'Estado', 'Acciones']}
        data={paginatedEvents}
        renderRow={(item) => (
          <tr key={item.id} className="hover:bg-neutral-50">
            <td className="px-5 py-3">
              <p className="font-semibold text-neutral-900">{item.nombre}</p>
              <p className="text-[10px] text-neutral-500 line-clamp-1">{item.descripcion}</p>
            </td>
            <td className="px-5 py-3 text-xs text-neutral-600">{item.categoria}</td>
            <td className="px-5 py-3 text-xs text-neutral-600 font-medium">{getOrgName(item.organizacionId)}</td>
            <td className="px-5 py-3 text-xs text-neutral-600">{formatDate(item.fecha)}</td>
            <td className="px-5 py-3 text-xs">
              <Badge variant={item.estado === 'activo' ? 'success' : 'neutral'}>
                {item.estado}
              </Badge>
            </td>
            <td className="px-5 py-3 text-xs flex gap-2">
              <button onClick={() => handleOpenEdit(item)} className="p-1 rounded text-neutral-500 hover:text-neutral-950 hover:bg-neutral-100">
                <Edit className="w-4 h-4" />
              </button>
              <button onClick={() => handleOpenDelete(item.id)} className="p-1 rounded text-red-500 hover:text-red-700 hover:bg-red-50">
                <Trash2 className="w-4 h-4" />
              </button>
            </td>
          </tr>
        )}
      />

      <Pagination
        currentPage={eventPage}
        totalPages={eventTotalPages}
        onPageChange={setEventPage}
        pageSize={eventPageSize}
        onPageSizeChange={setEventPageSize}
        pageSizeOptions={[5, 10, 15]}
        totalItems={eventTotalItems}
        itemName="eventos"
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingEvent ? 'Editar Evento de Voluntariado' : 'Crear Convocatoria / Campaña'}
        size="lg"
        footer={
          <div className="flex justify-end gap-3 w-full">
            <Button 
              type="button" 
              variant="outline" 
              size="sm" 
              onClick={() => setIsModalOpen(false)}
              className="rounded-xl font-bold px-5"
            >
              Cancelar
            </Button>
            <Button 
              type="submit" 
              form="event-form" 
              variant="primary" 
              size="sm"
              className="rounded-xl font-bold px-6 bg-red-600 hover:bg-red-700 text-white border-0 shadow-xs shadow-red-600/10"
            >
              {editingEvent ? 'Guardar Cambios' : 'Crear Convocatoria'}
            </Button>
          </div>
        }
      >
        <form id="event-form" onSubmit={handleSubmit(onSubmit)} className="space-y-6 max-h-[60vh] overflow-y-auto px-1 pr-2">
          {formError && (
            <div className="p-3.5 bg-red-50 border border-red-200 text-xs text-red-700 rounded-xl font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* Sección 1: Información General */}
          <div className="space-y-4 bg-neutral-50/50 p-5 rounded-2xl border border-neutral-150 shadow-2xs">
            <h4 className="text-xs font-black uppercase tracking-wider text-neutral-800 flex items-center gap-1.5 border-b border-neutral-200/60 pb-2 mb-3">
              Información General de la Campaña
            </h4>
            
            <Input
              label="Título del Evento / Campaña *"
              error={errors.nombre?.message}
              {...register('nombre', { required: 'El título es obligatorio' })}
              placeholder="Ej. Reforestación Parque Simón Bolívar"
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Select
                label="Organización Organizadora *"
                options={organizations.map(o => ({ value: o.id, label: o.nombre }))}
                {...register('organizacionId')}
              />

              <Select
                label="Categoría Temática *"
                options={categories.map(c => ({ value: c.nombre, label: c.nombre }))}
                {...register('categoria')}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                type="date"
                label="Fecha Programada *"
                error={errors.fecha?.message}
                {...register('fecha', { required: 'La fecha es obligatoria' })}
              />

              <Select
                label="Estado de la Campaña *"
                options={[
                  { value: 'activo', label: 'Activo / Abierto' },
                  { value: 'finalizado', label: 'Finalizado' },
                  { value: 'cancelado', label: 'Cancelado' },
                ]}
                {...register('estado')}
              />

              <Input
                type="number"
                label="Cupo de Voluntarios (0 para ilimitado)"
                error={errors.cupo?.message}
                {...register('cupo')}
                placeholder="Ej. 25"
              />
            </div>

            <Textarea
              label="Descripción detallada *"
              error={errors.descripcion?.message}
              {...register('descripcion', { required: 'La descripción es obligatoria' })}
              placeholder="Escribe los detalles de la labor, qué deben llevar los voluntarios, etc."
              rows={4}
            />
          </div>

          {/* Sección 2: Imagen del Evento */}
          <div className="bg-neutral-50/50 p-5 rounded-2xl border border-neutral-150 space-y-4 shadow-2xs">
            <h4 className="text-xs font-black uppercase tracking-wider text-neutral-800 flex items-center gap-1.5 border-b border-neutral-200/60 pb-2 mb-2">
              Imagen Ilustrativa del Evento
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-4">
                <Input
                  label="Enlace / URL de Imagen"
                  placeholder="https://images.unsplash.com/... o pega cualquier URL"
                  {...register('imagen')}
                />
                
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-extrabold text-neutral-500 uppercase tracking-widest">O selecciona un archivo local</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="w-full text-xs text-neutral-600 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-red-600 file:text-white hover:file:bg-red-700 cursor-pointer border border-neutral-200 rounded-xl p-1 bg-white shadow-3xs"
                  />
                </div>
              </div>

              <div className="border border-dashed border-neutral-300 rounded-2xl p-4 bg-white flex flex-col items-center justify-center min-h-[140px] overflow-hidden relative shadow-3xs">
                {watchedImagen ? (
                  <div className="w-full text-center space-y-2">
                    <img 
                      src={watchedImagen} 
                      alt="Previsualización" 
                      className="max-h-[100px] mx-auto object-cover rounded-xl w-full shadow-3xs" 
                      referrerPolicy="no-referrer" 
                    />
                    <button
                      type="button"
                      onClick={() => setValue('imagen', '')}
                      className="text-[10px] font-black text-red-600 hover:text-red-700 uppercase tracking-wider block mx-auto cursor-pointer"
                    >
                      Remover Imagen
                    </button>
                  </div>
                ) : (
                  <div className="text-center text-neutral-400 p-2">
                    <div className="w-8 h-8 mx-auto mb-1 rounded-full bg-neutral-100 flex items-center justify-center text-neutral-400 font-bold text-xs">IMG</div>
                    <span className="text-[10px] font-extrabold block mt-1 uppercase tracking-wider text-neutral-500">Sin imagen</span>
                    <span className="text-[9px] text-neutral-400 block mt-0.5">Se usará un banner automático por categoría</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sección 3: Ubicación */}
          <div className="space-y-5 bg-neutral-50/50 p-5 rounded-2xl border border-neutral-150 shadow-2xs">
            <h4 className="text-xs font-black uppercase tracking-wider text-neutral-800 flex items-center gap-1.5 border-b border-neutral-200/60 pb-2 mb-2">
              Ubicación y Geolocalización
            </h4>
            
            {/* Embedded map location picker */}
            <LocationPicker
              lat={watchedLat}
              lng={watchedLng}
              initialSearchTerm={watchedDireccion}
              onChange={handleLocationChange}
            />

            {/* Address Form Fields */}
            <Input
              label="Dirección Completa en Kennedy *"
              error={errors.direccion?.message}
              {...register('direccion', { required: 'La dirección completa es obligatoria' })}
              placeholder="Ej. Calle 42 Sur # 78K - 10"
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Barrio en Kennedy *"
                error={errors.barrio?.message}
                {...register('barrio', { required: 'El barrio es obligatorio' })}
                placeholder="Ej. Kennedy Central, Castilla, Timiza, Patio Bonito"
              />

              <div className="flex flex-col justify-center px-4 py-2 bg-neutral-100 rounded-xl border border-neutral-200 text-xs">
                <span className="text-[10px] font-black uppercase tracking-wider text-neutral-400">Zona de Cobertura</span>
                <span className="font-bold text-neutral-800">Localidad de Kennedy — Bogotá D.C.</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Nombre del Lugar (Opcional)"
                {...register('nombre_lugar')}
                placeholder="Ej. Parque Simón Bolívar - Zona 3"
              />

              <Input
                label="Punto de Referencia (Opcional)"
                {...register('punto_referencia')}
                placeholder="Ej. Al lado de la concha acústica"
              />
            </div>

            <div className="grid grid-cols-2 gap-4 bg-neutral-100 p-3.5 rounded-xl border border-neutral-200 text-xs text-neutral-600 font-mono">
              <div>
                <label className="block text-[9px] font-black text-neutral-400 uppercase tracking-wider">Latitud (Generada en Mapa)</label>
                <input
                  type="text"
                  readOnly
                  className="bg-transparent border-none p-0 m-0 w-full font-mono text-neutral-850 font-bold outline-none focus:ring-0 select-all"
                  {...register('latitud')}
                />
              </div>
              <div>
                <label className="block text-[9px] font-black text-neutral-400 uppercase tracking-wider">Longitud (Generada en Mapa)</label>
                <input
                  type="text"
                  readOnly
                  className="bg-transparent border-none p-0 m-0 w-full font-mono text-neutral-850 font-bold outline-none focus:ring-0 select-all"
                  {...register('longitud')}
                />
              </div>
            </div>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Eliminar Evento"
        message="¿Está seguro de eliminar esta campaña de voluntariado? Todos los registros de asistencia de los voluntarios se borrarán permanentemente."
      />
    </div>
  );
};

/**
 * ==========================================
 * 5. ADMIN DONATIONS
 * ==========================================
 */
export const AdminDonations: React.FC = () => {
  const [donations, setDonations] = useState<DonacionCompleta[]>([]);
  const [categories, setCategories] = useState<Categoria[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'todos' | 'monetaria' | 'objeto'>('todos');
  const [categoryFilter, setCategoryFilter] = useState('todas');
  const [selectedDonation, setSelectedDonation] = useState<DonacionCompleta | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const [list, cats] = await Promise.all([
      DonationService.getAll(),
      CategoryService.getAll()
    ]);
    setDonations(list);
    setCategories(cats);
  }

  const handleOpenDetails = (don: DonacionCompleta) => {
    setSelectedDonation(don);
    setIsModalOpen(true);
  };

  const filteredDonations = donations.filter(d => {
    const term = searchTerm.toLowerCase();
    const matchesSearch = 
      (d.usuarioNombre || '').toLowerCase().includes(term) ||
      (d.organizacionNombre || '').toLowerCase().includes(term) ||
      (d.categoria || '').toLowerCase().includes(term);
    const matchesType = typeFilter === 'todos' || d.tipo === typeFilter;
    const matchesCategory = categoryFilter === 'todas' || d.categoria.toLowerCase() === categoryFilter.toLowerCase();
    return matchesSearch && matchesType && matchesCategory;
  });

  const {
    paginatedData: paginatedDonations,
    currentPage: donPage,
    pageSize: donPageSize,
    totalPages: donTotalPages,
    totalItems: donTotalItems,
    setPage: setDonPage,
    setPageSize: setDonPageSize,
  } = usePagination(filteredDonations, { initialPageSize: 15, pageSizeOptions: [5, 10, 15] });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-neutral-900 uppercase tracking-wider">Historial de Donaciones</h1>
        <p className="text-xs text-neutral-500 mt-1">Supervisa y verifica todas las aportaciones económicas y de insumos.</p>
      </div>

      <div className="bg-white border border-neutral-200 p-4 rounded-xl shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex-1 max-w-md">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Buscar por donante, ONG, categoría..." />
        </div>
        <div className="flex items-center flex-wrap gap-2">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as any)}
            className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
            aria-label="Filtrar por tipo de donación"
          >
            <option value="todos">Todos los tipos</option>
            <option value="monetaria">Monetarias</option>
            <option value="objeto">En especie</option>
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
            aria-label="Filtrar por categoría de donación"
          >
            <option value="todas">Todas las categorías</option>
            {categories.map((c) => (
              <option key={c.id} value={c.nombre}>
                {c.nombre}
              </option>
            ))}
          </select>
        </div>
      </div>

      {paginatedDonations.length === 0 ? (
        <EmptyState
          title="No se encontraron donaciones"
          description="Intente ajustar el criterio de búsqueda o filtre por otra categoría o tipo."
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {paginatedDonations.map((don) => (
            <DonationCard
              key={don.id}
              donation={don}
              onViewDetails={handleOpenDetails}
            />
          ))}
        </div>
      )}

      <Pagination
        currentPage={donPage}
        totalPages={donTotalPages}
        onPageChange={setDonPage}
        pageSize={donPageSize}
        onPageSizeChange={setDonPageSize}
        pageSizeOptions={[5, 10, 15]}
        totalItems={donTotalItems}
        itemName="donaciones"
      />

      <DonationDetailsModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedDonation(null);
        }}
        donation={selectedDonation}
      />
    </div>
  );
};

/**
 * ==========================================
 * 6. ADMIN CATEGORIES
 * ==========================================
 */
export const AdminCategories: React.FC = () => {
  const [categories, setCategories] = useState<Categoria[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'todos' | 'activo' | 'inactivo'>('todos');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<Categoria | null>(null);

  // Confirm
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [catToDelete, setCatToDelete] = useState<string | null>(null);

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<Omit<Categoria, 'id'>>();

  useEffect(() => {
    loadCats();
  }, []);

  async function loadCats() {
    const list = await CategoryService.getAll();
    setCategories(list);
  }

  const handleOpenCreate = () => {
    setEditingCat(null);
    reset({ nombre: '', descripcion: '', estado: 'activo' });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (cat: Categoria) => {
    setEditingCat(cat);
    setValue('nombre', cat.nombre);
    setValue('descripcion', cat.descripcion);
    setValue('estado', cat.estado);
    setIsModalOpen(true);
  };

  const onSubmit = async (data: Omit<Categoria, 'id'>) => {
    if (editingCat) {
      await CategoryService.update(editingCat.id, data);
    } else {
      await CategoryService.create(data);
    }
    loadCats();
    setIsModalOpen(false);
  };

  const handleOpenDelete = (id: string) => {
    setCatToDelete(id);
    setIsConfirmOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (catToDelete) {
      await CategoryService.delete(catToDelete);
      loadCats();
    }
  };

  const filteredCategories = categories.filter(c => {
    const term = searchTerm.toLowerCase();
    const matchesSearch = 
      c.nombre.toLowerCase().includes(term) ||
      (c.descripcion || '').toLowerCase().includes(term);
    const matchesStatus = statusFilter === 'todos' || c.estado === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const {
    paginatedData: paginatedCategories,
    currentPage: catPage,
    pageSize: catPageSize,
    totalPages: catTotalPages,
    totalItems: catTotalItems,
    setPage: setCatPage,
    setPageSize: setCatPageSize,
  } = usePagination(filteredCategories, { initialPageSize: 15, pageSizeOptions: [5, 10, 15] });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-black text-neutral-900 uppercase tracking-wider">Gestión de Categorías</h1>
          <p className="text-xs text-neutral-500 mt-1">Administra las etiquetas operativas de los eventos y donaciones.</p>
        </div>
        <Button variant="primary" size="sm" onClick={handleOpenCreate}>
          <Plus className="w-4 h-4 mr-1" />
          Registrar Categoría
        </Button>
      </div>

      <div className="bg-white border border-neutral-200 p-4 rounded-xl shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex-1 max-w-md">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Buscar por nombre o descripción..." />
        </div>
        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="text-xs bg-white border border-neutral-200 rounded-xl px-3 py-2 text-neutral-700 font-semibold focus:outline-none focus:ring-2 focus:ring-brand/20"
            aria-label="Filtrar por estado de categoría"
          >
            <option value="todos">Todos los estados</option>
            <option value="activo">Activos</option>
            <option value="inactivo">Inactivos</option>
          </select>
        </div>
      </div>

      <Table<Categoria>
        headers={['ID', 'Categoría', 'Descripción', 'Estado', 'Acciones']}
        data={paginatedCategories}
        renderRow={(item) => (
          <tr key={item.id} className="hover:bg-neutral-50">
            <td className="px-5 py-3 text-xs font-mono text-neutral-400">{item.id}</td>
            <td className="px-5 py-3 font-semibold text-neutral-950">{item.nombre}</td>
            <td className="px-5 py-3 text-xs text-neutral-600 max-w-sm">{item.descripcion}</td>
            <td className="px-5 py-3 text-xs">
              <Badge variant={item.estado === 'activo' ? 'success' : 'neutral'}>
                {item.estado}
              </Badge>
            </td>
            <td className="px-5 py-3 text-xs flex gap-2">
              <button onClick={() => handleOpenEdit(item)} className="p-1 rounded text-neutral-500 hover:text-neutral-950 hover:bg-neutral-100">
                <Edit className="w-4 h-4" />
              </button>
              <button onClick={() => handleOpenDelete(item.id)} className="p-1 rounded text-red-500 hover:text-red-700 hover:bg-red-50">
                <Trash2 className="w-4 h-4" />
              </button>
            </td>
          </tr>
        )}
      />

      <Pagination
        currentPage={catPage}
        totalPages={catTotalPages}
        onPageChange={setCatPage}
        pageSize={catPageSize}
        onPageSizeChange={setCatPageSize}
        pageSizeOptions={[5, 10, 15]}
        totalItems={catTotalItems}
        itemName="categorías"
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCat ? 'Editar Categoría' : 'Crear Nueva Categoría'}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Input
            label="Nombre de Categoría"
            error={errors.nombre?.message}
            {...register('nombre', { required: 'El nombre es requerido' })}
          />

          <Textarea
            label="Descripción General"
            error={errors.descripcion?.message}
            {...register('descripcion', { required: 'La descripción es requerida' })}
          />

          <Select
            label="Estado"
            options={[
              { value: 'activo', label: 'Activo' },
              { value: 'inactivo', label: 'Inactivo' },
            ]}
            {...register('estado')}
          />

          <div className="pt-4 flex justify-end gap-2">
            <Button type="button" variant="outline" size="sm" onClick={() => setIsModalOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Guardar Categoría
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={isConfirmOpen}
        onClose={() => setIsConfirmOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Eliminar Categoría"
        message="¿Está seguro de eliminar esta categoría del sistema?"
      />
    </div>
  );
};
