import React from 'react';
import { Search, Loader2, AlertCircle, CheckCircle, Info, X } from 'lucide-react';

/**
 * ==========================================
 * 0. UTILITIES
 * ==========================================
 */
export const formatCOP = (value: number): string => {
  const rounded = Math.round(value);
  const formatted = rounded.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `$ ${formatted}`;
};

export const formatDate = (dateStr: string): string => {
  if (!dateStr) return '';
  
  // If it's already in DD/MM/YYYY format
  if (dateStr.includes('/') && dateStr.split('/').length === 3) {
    const parts = dateStr.split('/');
    if (parts[0].length === 2 && parts[2].length === 4) {
      return dateStr;
    }
  }
  
  // Try splitting by '-' (YYYY-MM-DD or YYYY-M-D)
  const parts = dateStr.split('T')[0].split('-');
  if (parts.length === 3) {
    const yyyy = parts[0];
    const mm = parts[1].padStart(2, '0');
    const dd = parts[2].padStart(2, '0');
    return `${dd}/${mm}/${yyyy}`;
  }
  return dateStr;
};

/**
 * ==========================================
 * 1. BUTTON COMPONENT
 * ==========================================
 */
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  className = '',
  disabled,
  ...props
}) => {
  const baseStyle = 'inline-flex items-center justify-center font-bold uppercase tracking-wider rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-xs cursor-pointer';
  
  const variants = {
    primary: 'bg-red-600 hover:bg-red-700 text-white focus:ring-red-500 shadow-sm shadow-red-100',
    secondary: 'bg-neutral-900 hover:bg-black text-white focus:ring-neutral-900',
    danger: 'bg-red-700 hover:bg-red-800 text-white focus:ring-red-700',
    outline: 'border border-neutral-250 hover:bg-neutral-50 text-neutral-800 focus:ring-neutral-500 bg-white',
    ghost: 'hover:bg-neutral-50 text-neutral-700 focus:ring-neutral-500',
  };

  const sizes = {
    sm: 'px-3.5 py-1.5 text-[10px]',
    md: 'px-5 py-2.5 text-xs',
    lg: 'px-7 py-3 text-sm',
  };

  return (
    <button
      disabled={disabled || isLoading}
      className={`${baseStyle} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {isLoading && <Loader2 className="w-3.5 h-3.5 mr-2 animate-spin shrink-0" />}
      {children}
    </button>
  );
};

/**
 * ==========================================
 * 2. INPUT COMPONENT
 * ==========================================
 */
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, className = '', type = 'text', ...props }, ref) => {
    return (
      <div className="w-full mb-4">
        {label && (
          <label className="block text-[10px] font-extrabold text-neutral-500 uppercase tracking-widest mb-1.5 select-none">
            {label}
          </label>
        )}
        <input
          ref={ref}
          type={type}
          className={`w-full px-4 py-2.5 border text-sm rounded-lg bg-white text-neutral-950 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-red-500/10 focus:border-red-500 transition-all duration-150 ${
            error ? 'border-red-600 focus:ring-red-600' : 'border-neutral-250'
          } ${className}`}
          {...props}
        />
        {error && <p className="mt-1.5 text-xs text-red-600 font-bold">{error}</p>}
      </div>
    );
  }
);

Input.displayName = 'Input';

/**
 * ==========================================
 * 3. TEXTAREA COMPONENT
 * ==========================================
 */
interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
}

export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, error, className = '', rows = 3, ...props }, ref) => {
    return (
      <div className="w-full mb-4">
        {label && (
          <label className="block text-[10px] font-extrabold text-neutral-500 uppercase tracking-widest mb-1.5 select-none">
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          rows={rows}
          className={`w-full px-4 py-2.5 border text-sm rounded-lg bg-white text-neutral-950 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-red-500/10 focus:border-red-500 transition-all duration-150 ${
            error ? 'border-red-600 focus:ring-red-600' : 'border-neutral-250'
          } ${className}`}
          {...props}
        />
        {error && <p className="mt-1.5 text-xs text-red-600 font-bold">{error}</p>}
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';

/**
 * ==========================================
 * 4. SELECT COMPONENT
 * ==========================================
 */
interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: { value: string; label: string }[];
}

export const Select = React.forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, error, options, className = '', ...props }, ref) => {
    return (
      <div className="w-full mb-4">
        {label && (
          <label className="block text-[10px] font-extrabold text-neutral-500 uppercase tracking-widest mb-1.5 select-none">
            {label}
          </label>
        )}
        <select
          ref={ref}
          className={`w-full px-4 py-2.5 border text-sm rounded-lg bg-white text-neutral-950 focus:outline-none focus:ring-2 focus:ring-red-500/10 focus:border-red-500 transition-all duration-150 cursor-pointer ${
            error ? 'border-red-600 focus:ring-red-600' : 'border-neutral-250'
          } ${className}`}
          {...props}
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        {error && <p className="mt-1.5 text-xs text-red-600 font-bold">{error}</p>}
      </div>
    );
  }
);

Select.displayName = 'Select';

/**
 * ==========================================
 * 5. CHECKBOX COMPONENT
 * ==========================================
 */
interface CheckboxProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(
  ({ label, error, className = '', ...props }, ref) => {
    return (
      <div className="mb-4">
        <label className="inline-flex items-center cursor-pointer select-none">
          <input
            ref={ref}
            type="checkbox"
            className={`w-4 h-4 text-red-600 border-neutral-300 rounded focus:ring-red-500/20 cursor-pointer ${className}`}
            {...props}
          />
          <span className="ml-2.5 text-xs text-neutral-700 font-semibold">{label}</span>
        </label>
        {error && <p className="mt-1 text-xs text-red-600 font-bold">{error}</p>}
      </div>
    );
  }
);

Checkbox.displayName = 'Checkbox';

/**
 * ==========================================
 * 6. RADIO COMPONENT
 * ==========================================
 */
interface RadioProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export const Radio = React.forwardRef<HTMLInputElement, RadioProps>(
  ({ label, error, className = '', ...props }, ref) => {
    return (
      <div className="mb-2">
        <label className="inline-flex items-center cursor-pointer select-none">
          <input
            ref={ref}
            type="radio"
            className={`w-4 h-4 text-red-600 border-neutral-300 focus:ring-red-500/20 cursor-pointer ${className}`}
            {...props}
          />
          <span className="ml-2.5 text-xs text-neutral-700 font-semibold">{label}</span>
        </label>
        {error && <p className="mt-1 text-xs text-red-600 font-bold">{error}</p>}
      </div>
    );
  }
);

Radio.displayName = 'Radio';

/**
 * ==========================================
 * 7. CARD COMPONENT
 * ==========================================
 */
interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  subtitle?: string;
  headerAction?: React.ReactNode;
  footer?: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({
  children,
  className = '',
  title,
  subtitle,
  headerAction,
  footer,
}) => {
  return (
    <div className={`bg-white border border-neutral-200/80 rounded-xl shadow-xs overflow-hidden ${className}`}>
      {(title || subtitle || headerAction) && (
        <div className="px-6 py-4.5 border-b border-neutral-100 flex items-center justify-between bg-white">
          <div>
            {title && <h3 className="text-xs font-black uppercase tracking-widest text-neutral-900">{title}</h3>}
            {subtitle && <p className="text-[10px] text-neutral-500 font-medium uppercase mt-0.5">{subtitle}</p>}
          </div>
          {headerAction && <div className="shrink-0">{headerAction}</div>}
        </div>
      )}
      <div className="px-6 py-5">{children}</div>
      {footer && <div className="px-6 py-3.5 bg-neutral-50/50 border-t border-neutral-100 flex justify-end gap-2">{footer}</div>}
    </div>
  );
};

/**
 * ==========================================
 * 8. MODAL COMPONENT
 * ==========================================
 */
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'md' | 'lg' | 'xl';
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  footer,
  size = 'md',
}) => {
  if (!isOpen) return null;

  const sizeClasses = {
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-2xl',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-neutral-900/40 backdrop-blur-xs" onClick={onClose} />
      
      {/* Content */}
      <div className={`relative bg-white border border-neutral-200 rounded-xl shadow-xl w-full ${sizeClasses[size]} z-10 overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in-50 zoom-in-95 duration-150`}>
        <div className="px-6 py-4.5 border-b border-neutral-100 flex items-center justify-between">
          <h3 className="text-xs font-black uppercase tracking-widest text-neutral-900">{title}</h3>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="px-6 py-5 overflow-y-auto flex-1">{children}</div>
        {footer && <div className="px-6 py-3.5 bg-neutral-50 border-t border-neutral-100 flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
};

/**
 * ==========================================
 * 9. LOADER COMPONENT
 * ==========================================
 */
export const Loader: React.FC<{ fullScreen?: boolean }> = ({ fullScreen = false }) => {
  const content = (
    <div className="flex flex-col items-center justify-center p-8 select-none">
      <Loader2 className="w-9 h-9 text-red-600 animate-spin" />
      <span className="mt-3 text-[10px] font-extrabold uppercase tracking-widest text-neutral-500">Cargando Give&amp;Go...</span>
    </div>
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 bg-white/90 backdrop-blur-xs flex items-center justify-center z-50">
        {content}
      </div>
    );
  }

  return content;
};

/**
 * ==========================================
 * 10. ALERT COMPONENT
 * ==========================================
 */
interface AlertProps {
  type?: 'success' | 'danger' | 'info';
  message: string;
  className?: string;
}

export const Alert: React.FC<AlertProps> = ({ type = 'info', message, className = '' }) => {
  const styles = {
    success: 'bg-green-50 border-green-150 text-green-800 rounded-lg',
    danger: 'bg-red-50 border-red-150 text-red-800 rounded-lg',
    info: 'bg-neutral-50 border-neutral-150 text-neutral-800 rounded-lg',
  };

  const icons = {
    success: <CheckCircle className="w-4 h-4 text-green-600 mr-2.5 shrink-0" />,
    danger: <AlertCircle className="w-4 h-4 text-red-600 mr-2.5 shrink-0" />,
    info: <Info className="w-4 h-4 text-neutral-500 mr-2.5 shrink-0" />,
  };

  return (
    <div className={`p-4 border flex items-start ${styles[type]} ${className}`}>
      <div className="mt-0.5">{icons[type]}</div>
      <span className="text-xs font-semibold leading-relaxed">{message}</span>
    </div>
  );
};

/**
 * ==========================================
 * 11. CONFIRM DIALOG COMPONENT
 * ==========================================
 */
interface ConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  type?: 'primary' | 'danger';
}

export const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = 'Confirmar',
  cancelText = 'Cancelar',
  type = 'danger',
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-neutral-900/40 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-white border border-neutral-200 rounded-xl shadow-xl w-full max-w-sm z-10 p-6 animate-in fade-in-50 zoom-in-95 duration-150">
        <h3 className="text-xs font-black uppercase tracking-widest text-neutral-900 mb-2">{title}</h3>
        <p className="text-xs font-semibold text-neutral-500 leading-relaxed mb-6">{message}</p>
        <div className="flex justify-end gap-2.5">
          <Button variant="outline" size="sm" onClick={onClose}>
            {cancelText}
          </Button>
          <Button variant={type === 'danger' ? 'danger' : 'primary'} size="sm" onClick={() => { onConfirm(); onClose(); }}>
            {confirmText}
          </Button>
        </div>
      </div>
    </div>
  );
};

/**
 * ==========================================
 * 12. PAGINATION COMPONENT
 * ==========================================
 */
interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  onPageChange,
}) => {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-center gap-2 mt-6 select-none">
      <Button
        variant="outline"
        size="sm"
        disabled={currentPage === 1}
        onClick={() => onPageChange(currentPage - 1)}
      >
        Anterior
      </Button>
      <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider px-3 bg-neutral-100 py-1.5 rounded-md">
        Pág {currentPage} de {totalPages}
      </span>
      <Button
        variant="outline"
        size="sm"
        disabled={currentPage === totalPages}
        onClick={() => onPageChange(currentPage + 1)}
      >
        Siguiente
      </Button>
    </div>
  );
};

/**
 * ==========================================
 * 13. SEARCH BAR COMPONENT
 * ==========================================
 */
interface SearchBarProps {
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onChange,
  placeholder = 'Buscar...',
}) => {
  return (
    <div className="relative w-full max-w-md">
      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
        <Search className="h-4 w-4 text-neutral-400" />
      </div>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="block w-full pl-10 pr-4 py-2.5 border border-neutral-250 rounded-lg text-sm bg-white text-neutral-950 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-red-500/10 focus:border-red-500 transition-all duration-150"
      />
    </div>
  );
};

/**
 * ==========================================
 * 14. TABLE COMPONENT
 * ==========================================
 */
interface TableProps<T> {
  headers: string[];
  data: T[];
  renderRow: (item: T, idx: number) => React.ReactNode;
}

export const Table = <T,>({ headers, data, renderRow }: TableProps<T>) => {
  return (
    <div className="w-full overflow-x-auto border border-neutral-200/80 rounded-xl shadow-xs bg-white">
      <table className="min-w-full divide-y divide-neutral-150 text-left text-xs text-neutral-700 bg-white">
        <thead className="bg-neutral-50/75 text-[10px] font-extrabold text-neutral-500 uppercase tracking-widest">
          <tr>
            {headers.map((h, i) => (
              <th key={i} className="px-6 py-4 font-extrabold select-none">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-neutral-150 text-neutral-800">
          {data.length === 0 ? (
            <tr>
              <td colSpan={headers.length} className="px-6 py-10 text-center text-neutral-400 font-semibold select-none uppercase tracking-wider text-[10px]">
                No hay registros disponibles.
              </td>
            </tr>
          ) : (
            data.map((item, idx) => renderRow(item, idx))
          )}
        </tbody>
      </table>
    </div>
  );
};

/**
 * ==========================================
 * 15. BADGE COMPONENT
 * ==========================================
 */
interface BadgeProps {
  children: React.ReactNode;
  variant?: 'success' | 'danger' | 'info' | 'warning' | 'neutral';
}

export const Badge: React.FC<BadgeProps> = ({ children, variant = 'neutral' }) => {
  const styles = {
    success: 'bg-green-50 text-green-700 border-green-200',
    danger: 'bg-red-50 text-red-700 border-red-200',
    info: 'bg-blue-50 text-blue-700 border-blue-200',
    warning: 'bg-amber-50 text-amber-700 border-amber-200',
    neutral: 'bg-neutral-50 text-neutral-600 border-neutral-200',
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-widest border ${styles[variant]} select-none`}>
      {children}
    </span>
  );
};

/**
 * ==========================================
 * 16. EMPTY STATE COMPONENT
 * ==========================================
 */
interface EmptyStateProps {
  title: string;
  description: string;
  actionText?: string;
  onAction?: () => void;
  icon?: React.ReactNode;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  actionText,
  onAction,
  icon,
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-10 text-center border-2 border-dashed border-neutral-200 rounded-xl bg-white select-none">
      {icon ? (
        <div className="mb-4 text-neutral-400">{icon}</div>
      ) : (
        <AlertCircle className="w-10 h-10 text-neutral-300 mb-4" />
      )}
      <h3 className="text-xs font-black uppercase tracking-widest text-neutral-900">{title}</h3>
      <p className="text-xs text-neutral-500 font-semibold max-w-xs mt-2 mb-6 leading-relaxed">{description}</p>
      {actionText && onAction && (
        <Button variant="primary" size="sm" onClick={onAction}>
          {actionText}
        </Button>
      )}
    </div>
  );
};
